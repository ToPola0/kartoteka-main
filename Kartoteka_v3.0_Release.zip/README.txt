======================================
  KARTOTEKA PARAFIALNA - INSTRUKCJA
======================================

1. Uruchom program klikajac: Uruchom.bat
   LUB bezposrednio: Kartoteka.exe

2. Logo Sw. Jadwigi jest wbudowane w program

3. Pliki konfiguracyjne:
   - settings.json (tworzone automatycznie)

4. Caly folder mozesz skopiowac na inny komputer

